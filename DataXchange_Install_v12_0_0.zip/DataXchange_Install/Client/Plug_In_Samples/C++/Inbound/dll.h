/*
   Inbound Plug-in DLL sample  
   Copyright: Datalynx Pty Ltd 2005-2006.    

*/

#ifndef _DLL_H_
#define _DLL_H_

#ifdef __cplusplus
extern "C" {
#endif

#if BUILDING_DLL
# define DLLIMPORT __declspec (dllexport)
#else /* Not BUILDING_DLL */
# define DLLIMPORT __declspec (dllimport)
#endif /* Not BUILDING_DLL */

int __stdcall DLLIMPORT open(char **pDLLPath,int iFromRec,char **pQuery,char **pException);
int __stdcall DLLIMPORT close(char **pException);
int __stdcall DLLIMPORT next(char **pException);
int __stdcall DLLIMPORT getfield(char **pFieldName,char **pFieldValue,char **pException);
int __stdcall DLLIMPORT getfieldsdef(char **pFieldDef,char **pException);

#ifdef __cplusplus
}
#endif


int iRecordCounter = 0;
int iTestMaxRecCount = 2; // this is to test only, not to be used for Implementation  

class CExceptions {
public:
   int ExceptionNo;
   CExceptions(int expNo) {ExceptionNo = expNo;};
   ~CExceptions() {};
   const char *GetException() const 
   { 
       switch (ExceptionNo)
        {
          case 1:
            return "Undefined Field Name";
    
          case 2:
            {   
              return "End Of Records";  
              break;
             };  
    
          // Add More cases to handle  your exceptions 
          default: return "Undefined Exception Number";  
        }         
   }
};

class DLLIMPORT CInBound
{
  private:
               
  public:
         
    int  FromRec;
    char MyQuery[8193]; // 8 KB     
    char MyDLLPath[256];         
    
    char FirstName[31];// Replace with your variable
    char LastName[31]; // Replace with your variable
    int   Age;
    float Salary;
    
    //CInBound(char **pDLLPath,int iFromRec);
    CInBound();
    virtual ~CInBound(void);
    int Mynext(char **pException);    
    
    // Add your class factions here    

};

CInBound *OInBound;

#endif /* _DLL_H_ */


