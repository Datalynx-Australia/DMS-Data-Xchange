/*
   Inbound Plug-in DLL sample  
   Copyright: Datalynx Pty Ltd 2005-2006.    

*/

#include "dll.h"
#include <windows.h>
#include <stdio.h>
#include <string>
//#include <stdexcept>
#include <exception>


//*************************** Interface Functions *****************************************

//*****************************************************************************************
//   int open(char *pDLLPath,int iFromRec)
//   Description: This function is used for Initialisation,and will be called  
//                Only at the beginning by the interface.
//
//   Note       :Once initialised correctly the interface expect to have the 
//                 first record or the (from record) record ready to read.
//
//   Parameters :[IN] char **pDLLPath :the path where the dll is installed.
//               [IN] int   iFromRec :the starting record number.
//               [OUT] char **pException: Returns the exception back to the interface;
//
//   Returns    : -1:FAIL ; 0:PASS ; 1:End Of Records
//
//*****************************************************************************************
__stdcall int open(char **pDLLPath,int iFromRec,char **pQuery,char **pException)
{
   int Result = 0; // 0:PASS ;       
   try       
   {
       OInBound = new CInBound();      
       strcpy(OInBound->MyDLLPath,*pDLLPath);
       strcpy(OInBound->MyQuery,*pQuery);
 
       // Load data and set pointer to the first record;
       strcpy(OInBound->FirstName,"Test First Name");
       strcpy(OInBound->LastName,"Test Last Name");
       OInBound->Age = 25;
       OInBound->Salary = 123456.78;                 
    
     // Your Code 
    
     // Result = 1 ;//  if no records to read.
    }
   catch( CExceptions E )    { strcpy(*pException,E.GetException()); Result = -1;}
   catch(std::exception& e) { strcpy(*pException,e.what()); Result = -1;}
   catch(char *Errstr)       { strcpy(*pException,Errstr);  Result = -1;}  
   catch(...)  { strcpy(*pException,"Undefined Exception"); Result = -1; }  
   return Result;         
}


//*****************************************************************************************
//   int close()
//   Description: This function is used for finalisation,and will be called only
//                at the end by the interface.
//
//   Parameters : [OUT] char **pException: Returns the exception back to the interface; 
//
//   Returns    : -1:FAIL; 0:PASS
//
//*****************************************************************************************
__stdcall int close(char **pException) 
{
   int Result = 0; // 0:PASS        
   try       
   {   
      // Your Code 
               
     delete OInBound;         
   }   
   catch( CExceptions E )    { strcpy(*pException,E.GetException()); Result = -1;}
   catch(std::exception& e) { strcpy(*pException,e.what()); Result = -1;}
   catch(char *Errstr)       { strcpy(*pException,Errstr);  Result = -1;}  
   catch(...)  { strcpy(*pException,"Undefined Exception"); Result = -1; }  
   return Result;         
}

//*****************************************************************************************
//   int int getfieldsdef(char **pFieldDef,char **pException);
//   Description: This function is used get the fields defintion,and will be called  
//                after the open function by the interface.
//
//
//   Parameters :[OUT] char **pFieldDef : Expected format: 
//               field1_name:field1_type:field1_len:field1_scale;
//               field2_name:field2_type:field2_len:field2_scale; ...
//               fieldn_name:fieldn_type:fieldn_len:fieldn_scale
//
//               [OUT] char *pException: Returns the exception back to the interface;
//
//   Supported Types:            
//                    STRING    
//                    INTEGER
//                    DATE_TIME
//                    DATE
//                    TIME
//                    FLOAT
//
//   Returns    : -1:FAIL ; 0:PASS 
//
//*****************************************************************************************
__stdcall int getfieldsdef(char **pFieldDef,char **pException)
{
   int Result = 0; //0:PASS                   
   try
   {    
     // Remove all code in try { } and replace it with your Code        
     strcpy(*pFieldDef,"FirstName:STRING:30:0;");                                           
     strcat(*pFieldDef,"LastName:STRING:30:0;");                                             
     strcat(*pFieldDef,"Age:INTEGER:0:0;");                                             
     strcat(*pFieldDef,"Salary:FLOAT:6:2;");                                                  
   }   
   catch( CExceptions E )    { strcpy(*pException,E.GetException()); Result = -1;}
   catch(std::exception& e) { strcpy(*pException,e.what()); Result = -1;}
   catch(char *Errstr)       { strcpy(*pException,Errstr);  Result = -1;}  
   catch(...)  { strcpy(*pException,"Undefined Exception"); Result = -1; }  
   return Result;         
          
}

//*****************************************************************************************
//   int next(char **pException)
//   Description: This function is used to move to the next record, it will be 
//                called the interface once all data fields are read from the 
//                previous record.
//
//   Parameters : [OUT] char **pException: Returns the exception back to the interface;
//
//   Returns:    -1:FAIL ; 0:PASS ; 1:End Of Records
//
//*****************************************************************************************
__stdcall int next(char **pException)
{
  return OInBound->Mynext(pException);   
}


//*****************************************************************************************
//   int getfield(const char *pFieldName,char *pFieldValue)
//   Description: This function is used for get the field by name, and the field
//                value will be passed back to the interface in pFieldValue parameter.
//
//   Parameters :[IN] char **pFieldName   : The data field name to be read.
//               [OUT] char **pFieldValue : The data field value,
//                                         the maximun size is 8192 bytes
//               [OUT] char **pException: Returns the exception back to the interface;
//
//   Returns    : -1:FAIL ; 0:PASS 
//
//*****************************************************************************************
__stdcall int getfield(char **pFieldName,char **pFieldValue,char **pException) 
{
   int Result = 0; //0:PASS                   
   char buffer [10];

   try
   {    
     // Remove all code in try { } and replace it with your Code        
     
     if (strcmp(strupr(*pFieldName),"FIRSTNAME") == 0 )
     {
       strcpy(*pFieldValue,OInBound->FirstName);                                           
     }                           
     else if (strcmp(strupr(*pFieldName),"LASTNAME") == 0 )
     {
       strcpy(*pFieldValue,OInBound->LastName);                                           
     }                           
     else if (strcmp(strupr(*pFieldName),"AGE") == 0 )
     {
      sprintf (*pFieldValue, "%d",OInBound->Age);  
     }                           
     else if (strcmp(strupr(*pFieldName),"SALARY") == 0 )
     {
      sprintf (*pFieldValue, "%6.2f",OInBound->Salary);  
     }                               
     else throw CExceptions(1);    
   }   
   catch( CExceptions E )    { strcpy(*pException,E.GetException()); Result = -1;}
   catch(std::exception& e) { strcpy(*pException,e.what()); Result = -1;}
   catch(char *Errstr)       { strcpy(*pException,Errstr);  Result = -1;}  
   catch(...)  { strcpy(*pException,"Undefined Exception"); Result = -1; }  
   return Result;         
}

//*************************** End OfInterface Functions ***********************************
//*****************************************************************************************




//*************************** Inbound Class ***********************************************

CInBound::CInBound()
{
}

CInBound::~CInBound ()
{

}

//*****************************************************************************************
//   int Mynext()
//   Description: This function is used to move to the next record, it will be 
//                called the interface once all data fields are read from the 
//                previous record.
//
//   Parameters : [OUT] char *pException: Returns the exception back to the interface;
//
//   Returns:    -1:FAIL ; 0:PASS ; 1:End Of Records
//
//*****************************************************************************************
int CInBound::Mynext(char **pException)    
{
  int Result = 0; //0:PASS         
  try
   { 
     // Remove all code in try { } and replace it with your Code                
     iRecordCounter ++ ;        
     
     strcpy(OInBound->FirstName,"Test First Name 2");
     strcpy(OInBound->LastName,"Test Last Name 2");
     OInBound->Age = 30;
     OInBound->Salary = 6543.12;                     
     
     
     if (iRecordCounter == iTestMaxRecCount) 
     {
       Result = 1 ; // 1:End Of Records                     
     }
   }   
   catch( CExceptions E )    { strcpy(*pException,E.GetException()); Result = -1;}
   catch(std::exception& e) { strcpy(*pException,e.what()); Result = -1;}
   catch(char *Errstr)       { strcpy(*pException,Errstr);  Result = -1;}  
   catch(...)  { strcpy(*pException,"Undefined Exception"); Result = -1; }  
   return Result;         
    
}


      

//*****************************************************************************************
//   BOOL APIENTRY DllMain (HINSTANCE hInst     /* Library instance handle. */ ,
//                       DWORD reason        /* Reason this function is being called. */ ,
//                       LPVOID reserved     /* Not used. */ )
//
//    This function is not user by the interface
//*****************************************************************************************

BOOL APIENTRY DllMain (HINSTANCE hInst     /* Library instance handle. */ ,
                       DWORD reason        /* Reason this function is being called. */ ,
                       LPVOID reserved     /* Not used. */ )
{
    switch (reason)
    {
      case DLL_PROCESS_ATTACH:            
        break;

      case DLL_PROCESS_DETACH:
          
        break;

      case DLL_THREAD_ATTACH:
             
        break;

      case DLL_THREAD_DETACH:
            
        break;
    }

    /* Returns TRUE on success, FALSE on failure */
    return TRUE;
}






