/* Replace "dll.h" with the name of your header */
#include "dll.h"
#include <windows.h>
#include <stdio.h>
#include <string>
#include <exception>


//*************************** Interface Functions *****************************************

//*****************************************************************************************
//   int open(char **pDLLPath,int iFromRec,char **pException)
//   Description: This function is used for Initialisation,and will be called  
//                Only at the beginning by the interface.
//
//   Parameters :[IN] char **pDLLPath :the path where the dll is installed.
//               [IN] int   iFromRec :the starting record number.
//               [OUT] char *pException: Returns the exception back to the interface;
//
//   Returns    : -1:FAIL ; 0:PASS 
//
//*****************************************************************************************
__stdcall int open(char **pDLLPath,int iFromRec,char **pQuery,char **pException)
{
   int Result = 0; // 0:PASS ;       
   try       
   {
       OOutBound = new COutBound();      
       strcpy(OOutBound->MyDLLPath,*pDLLPath);
         
     // Your Code 
       
    }
   catch( CExceptions E )    { strcpy(*pException,E.GetException()); Result = -1;}
   catch(std::exception& e) { strcpy(*pException,e.what()); Result = -1;}
   catch(char *Errstr)       { strcpy(*pException,Errstr);  Result = -1;}  
   catch(...)  { strcpy(*pException,"Undefined Exception"); Result = -1;}  
   return Result;         
}


//*****************************************************************************************
//   int close(char **pException)
//   Description: This function is used for finalisation,and will be called only
//                at the end by the interface.
//
//   Parameters : [OUT] char *pException: Returns the exception back to the interface; 
//
//   Returns    : -1:FAIL; 0:PASS
//
//*****************************************************************************************
__stdcall int close(char **pException) 
{
   int Result = 0; // 0:PASS        
   try       
   {   
      // Your Code 
               
      delete OOutBound;        
   }   
   catch( CExceptions E )    { strcpy(*pException,E.GetException()); Result = -1;}
   catch(std::exception& e) { strcpy(*pException,e.what()); Result = -1;}
   catch(char *Errstr)       { strcpy(*pException,Errstr);  Result = -1;}  
   catch(...)  { strcpy(*pException,"Undefined Exception"); Result = -1;}  
   return Result;         
}


//*****************************************************************************************
//   int int getfieldsdef(char **pFieldDef,char **pException);
//   Description: This function is used get the fields defintion,and will be called  
//                after the open function by the interface.
//
//
//   Parameters :[OUT] char **pFieldDef : Expected format: 
//               field1_name:field1_type:field1_len:field1_scale;
//               field2_name:field2_type:field2_len:field2_scale; ...
//               fieldn_name:fieldn_type:fieldn_len:fieldn_scale
//
//               [OUT] char *pException: Returns the exception back to the interface;
//
//   Supported Types:            
//                    STRING    
//                    INTEGER
//                    DATE_TIME
//                    DATE
//                    TIME
//                    FLOAT
//
//   Returns    : -1:FAIL ; 0:PASS 
//
//*****************************************************************************************
__stdcall int getfieldsdef(char **pFieldDef,char **pException)
{
   int Result = 0; //0:PASS                   
   try
   {    
     // Remove all code in try { } and replace it with your Code        
     strcpy(*pFieldDef,"FirstName:STRING:30:0;");                                           
     strcat(*pFieldDef,"LastName:STRING:30:0;");                                             
     strcat(*pFieldDef,"Age:INTEGER:0:0;");                                             
     strcat(*pFieldDef,"Salary:FLOAT:6:2;");                                                  
   }   
   catch( CExceptions E )    { strcpy(*pException,E.GetException()); Result = -1;}
   catch(std::exception& e) { strcpy(*pException,e.what()); Result = -1;}
   catch(char *Errstr)       { strcpy(*pException,Errstr);  Result = -1;}  
   catch(...)  { strcpy(*pException,"Undefined Exception"); Result = -1; }  
   return Result;         
          
}


//*****************************************************************************************
//   int setfield(char **pFieldName,char **pFieldValue,char **pException) 
//   Description: This function is used for set the field by name, and the field
//                value will be passed from the interface in pFieldValue parameter.
//
//   Parameters :[IN] char *pFieldName   : The data field name to be read.
//               [IN] char *pFieldValue : The data field value,
//                                         the maximun size is 8192 bytes
//               [OUT] char *pException: Returns the exception back to the interface;
//
//   Returns    : -1:FAIL ; 0:PASS 
//
//*****************************************************************************************
__stdcall int setfield(char **pFieldName,char **pFieldValue,char **pException) 
{
   int Result = 0; //0:PASS                   
   try
   {    
     // Remove all code in try { } and replace it with your Code , this is example only
     if (strcmp(strupr(*pFieldName),"FIRSTNAME") == 0 )
     {
       strcpy(OOutBound->FirstName,*pFieldValue);                                           
     }                           
     else if (strcmp(strupr(*pFieldName),"LASTNAME") == 0 )
     {
       strcpy(OOutBound->LastName,*pFieldValue);                                           
     }                           
     else throw CExceptions(1);    
   }   
   catch( CExceptions E )    { strcpy(*pException,E.GetException()); Result = -1;}
   catch(std::exception& e) { strcpy(*pException,e.what()); Result = -1;}
   catch(char *Errstr)       { strcpy(*pException,Errstr);  Result = -1;}  
   catch(...)  { strcpy(*pException,"Undefined Exception"); Result = -1;}  
   return Result;         
}


//*****************************************************************************************
//   int insert(char **pException);
//   Description: This function is used to insert record into destination, it will be 
//                called by the interface once all data fields are set by "setfield" function. 
//
//   Parameters : [OUT] char *pException: Returns the exception back to the interface;
//
//   Returns:     -1:FAIL; 0:Rejected; 1..n:Accepted 
//
//*****************************************************************************************

__stdcall int insert(char **pException)
{
     return OOutBound->Myinsert(pException);       
}

//*****************************************************************************************
//   int update(char **pException);
//   Description: This function is used to update record into destination, it will be 
//                called by the interface once all data fields are set by "setfield" function. 
//
//   Parameters : [OUT] char *pException: Returns the exception back to the interface;
//
//   Returns:     -1:FAIL; 0:Rejected; 1..n:Accepted 
//
//*****************************************************************************************

__stdcall int update(char **pException)
{

   return OOutBound->Myupdate(pException);  
    
}

//*****************************************************************************************
//   int update_insert(char **pException);
//   Description: This function is used to update_insert record into destination, it will be 
//                called by the interface once all data fields are set by "setfield" function. 
//
//   Parameters : [OUT] char *pException: Returns the exception back to the interface;
//
//   Returns:     -1:FAIL; 0:Rejected; 1..n:Accepted 
//
//*****************************************************************************************

__stdcall int update_insert(char **pException)
{
    return  OOutBound->Myupdate_insert(pException);     
}


//*****************************************************************************************
//   int delete_record(char **pException);
//   Description: This function is used to delete record from the destination, it will be 
//                called by the interface once all data fields are set by "setfield" function. 
//
//   Parameters : [OUT] char *pException: Returns the exception back to the interface;
//
//   Returns:     -1:FAIL; 0:Rejected; 1..n:Accepted 
//
//*****************************************************************************************

__stdcall int delete_record(char **pException)
{
    return OOutBound->Mydelete_record(pException);      
}



//*************************** End OfInterface Functions ***********************************
//*****************************************************************************************




//*************************** Outbound Class ***********************************************

COutBound::COutBound()
{

}

COutBound::~COutBound ()
{

}

int COutBound::Myinsert(char ** pException)
{
  int Result = 0; //0:Rejected         
  try
   {  
     //Insert your insert record code here;
     // Result = n; if n records where inserted;
   }   
   catch( CExceptions E )    { strcpy(*pException,E.GetException()); Result = -1;}
   catch(std::exception& e) { strcpy(*pException,e.what()); Result = -1;}
   catch(char *Errstr)       { strcpy(*pException,Errstr);  Result = -1;}  
   catch(...)  { strcpy(*pException,"Undefined Exception"); Result = -1; }  
   return Result;              
}

int COutBound::Myupdate(char ** pException)
{
  int Result = 0; //0:Rejected         
  try
   {            
     //Insert your update record code here;
     // Result = n; if n records where updated ;
   }   
   catch( CExceptions E )    { strcpy(*pException,E.GetException()); Result = -1;}
   catch(std::exception& e) { strcpy(*pException,e.what()); Result = -1;}
   catch(char *Errstr)       { strcpy(*pException,Errstr);  Result = -1;}  
   catch(...)  { strcpy(*pException,"Undefined Exception"); Result = -1; }  
   return Result;          
}

int COutBound::Myupdate_insert(char ** pException)
{
  int Result = 0; //0:Rejected         
  try
   {            
     //Insert your update - insert record code here;
     // Result = n; if n records where updated or inserted;
   }   
   catch( CExceptions E )    { strcpy(*pException,E.GetException()); Result = -1;}
   catch(std::exception& e) { strcpy(*pException,e.what()); Result = -1;}
   catch(char *Errstr)       { strcpy(*pException,Errstr);  Result = -1;}  
   catch(...)  { strcpy(*pException,"Undefined Exception"); Result = -1; }  
   return Result;         
   
}

int COutBound::Mydelete_record(char ** pException)    
{
    
  int Result = 0; //0:Rejected         
  try
   {            
     //Insert your delete record code here;
     // Result = n; if n records where deleted;
   }   
   catch( CExceptions E )    { strcpy(*pException,E.GetException()); Result = -1;}
   catch(std::exception& e) { strcpy(*pException,e.what()); Result = -1;}
   catch(char *Errstr)       { strcpy(*pException,Errstr);  Result = -1;}  
   catch(...)  { strcpy(*pException,"Undefined Exception"); Result = -1; }  
   return Result;           
    
}

    

//*****************************************************************************************
//   BOOL APIENTRY DllMain (HINSTANCE hInst     /* Library instance handle. */ ,
//                       DWORD reason        /* Reason this function is being called. */ ,
//                       LPVOID reserved     /* Not used. */ )
//
//    This function is not user by the interface
//*****************************************************************************************

BOOL APIENTRY DllMain (HINSTANCE hInst     /* Library instance handle. */ ,
                       DWORD reason        /* Reason this function is being called. */ ,
                       LPVOID reserved     /* Not used. */ )
{
    switch (reason)
    {
      case DLL_PROCESS_ATTACH:
        break;

      case DLL_PROCESS_DETACH:
        break;

      case DLL_THREAD_ATTACH:
        break;

      case DLL_THREAD_DETACH:
        break;
    }

    /* Returns TRUE on success, FALSE on failure */
    return TRUE;
}






