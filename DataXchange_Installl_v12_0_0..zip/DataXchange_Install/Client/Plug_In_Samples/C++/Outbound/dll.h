/*
   Inbound Plug-in DLL skeleton  
   Copyright: Datalynx Pty Ltd.    

*/

#ifndef _DLL_H_
#define _DLL_H_

#ifdef __cplusplus
extern "C" {
#endif

#if BUILDING_DLL
# define DLLIMPORT __declspec (dllexport)
#else /* Not BUILDING_DLL */
# define DLLIMPORT __declspec (dllimport)
#endif /* Not BUILDING_DLL */

int __stdcall DLLIMPORT open(char **pDLLPath,int iFromRec,char **pQuery,char **pException);
int __stdcall DLLIMPORT close(char **pException);
int __stdcall DLLIMPORT insert(char **pException); // -1:FAIL; 0:Rejected; 1..n:Accepted 
int __stdcall DLLIMPORT update(char **pException); // -1:FAIL; 0:Rejected; 1..n:Accepted 
int __stdcall DLLIMPORT update_insert(char **pException); // -1:FAIL; 0:Rejected; 1..n:Accepted 
int __stdcall DLLIMPORT delete_record(char **pException);     // -1:FAIL; 0:Rejected; 1..n:Accepted 
int __stdcall DLLIMPORT setfield(char **pFieldName,char **pFieldValue,char **pException); // -1:FAIL; 0:PASS
int __stdcall DLLIMPORT getfieldsdef(char **pFieldDef,char **pException);
                        
#ifdef __cplusplus
}
#endif


int iRecordCounter = 0;
int iTestMaxRecCount = 1; // this is to test only, not to be used for Implementation  

class CExceptions {
public:
   int ExceptionNo;
   CExceptions(int expNo) {ExceptionNo = expNo;};
   ~CExceptions() {};
   const char *GetException() const 
   { 
       switch (ExceptionNo)
        {
          case 1:
            return "Undefined Field Name";
    
          case 2:
            {   
              break;
             };  
    
          // Add More cases to handle  your exceptions 
          default: return "Undefined Exception Number";  
        }         
   }
};

class DLLIMPORT COutBound
{
  private:
                
  public:
     
    int  FromRec;    
    char MyDLLPath[256];                 

    char FirstName[31];// Replace with your variable
    char LastName[31]; // Replace with your variable
    int   Age;
    float Salary;
  
                 
    COutBound();
    virtual ~COutBound(void);
    int Myinsert(char ** pException);
    int Myupdate(char ** pException);
    int Myupdate_insert(char ** pException);    
    int Mydelete_record(char ** pException);    
        
    // Add your class factions here    

};

COutBound *OOutBound;

#endif /* _DLL_H_ */


